# Stillroom

A dependency-free frontend prototype for an AI-powered reflection companion. It demonstrates the main journaling flow with local mock responses and saves reflections in the current browser using `localStorage`.

## Run it

Open `index.html` in a modern browser. No build step, account, network service, or API key is required.

## Prototype behavior

- Start with free text or one of the gentle prompts.
- “Speak” demonstrates the voice-input state with editable sample text; it does not record audio.
- The reflection conversation and follow-up are local mock interactions.
- Saving a reflection stores it in this browser. Past reflections and patterns are available from the left navigation.
- “Clear site data” in the browser removes saved reflections.

The app is structured across `index.html`, `styles.css`, and `app.js` so mock response generation and persistence can later be replaced independently.
